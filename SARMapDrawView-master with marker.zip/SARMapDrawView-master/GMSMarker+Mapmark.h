//
//  GMSMarker+Mapmark.h
//  SARMapDrawView
//
//  Created by C N Soft Net on 30/08/16.
//  Copyright © 2016 Saravanan. All rights reserved.
//

#import <GoogleMaps/GoogleMaps.h>

@interface GMSMarker (Mapmark)

- (GMSMarker *)initmarker:(CLLocationCoordinate2D)position;

@end

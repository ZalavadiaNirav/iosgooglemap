//
//  GMSMarker+Mapmark.m
//  SARMapDrawView
//
//  Created by C N Soft Net on 30/08/16.
//  Copyright © 2016 Saravanan. All rights reserved.
//

#import "GMSMarker+Mapmark.h"

@implementation GMSMarker (Mapmark)


- (GMSMarker *)initmarker:(CLLocationCoordinate2D)position
{
    
    GMSMarker *mark = [GMSMarker markerWithPosition:position] ;
    mark.title = @"London";
    mark.snippet = @"Population: 8,174,100";
    mark.infoWindowAnchor = CGPointMake(0.5, 0.5);
//    mark.icon = [UIImage imageNamed:@"house"];
    return mark;
}


@end
